# 🤖 Actualización automática de resultados — Prode Mundial 2026

Este paquete agrega al repo un robot que revisa los resultados cada 30 minutos
y, si encuentra un partido jugado que todavía no tiene resultado cargado en el
prode, lo actualiza solo y hace commit.

## ¿Cómo funciona?

1. Un **GitHub Action** corre cada 30 minutos (también se puede disparar a mano).
2. Descarga el fixture/resultados público de `openfootball/worldcup.json`
   (gratis, sin API key).
3. Compara con `data/calendario.json` (horarios ART de cada partido).
4. Si un partido ya pasó **2h10m desde el kickoff** y la fuente ya tiene el
   resultado final, lo escribe en `index.html` (variable `results`).
5. Si hubo cambios, el bot hace `git commit` y `git push` automáticamente.
   GitHub Pages se republica solo.

## ⚠️ Importante — limitación de la fuente de datos

La fuente (`openfootball/worldcup.json`) **se actualiza manualmente, una vez
por día aproximadamente** (no es instantánea). Esto significa:

- A veces el resultado puede demorar varias horas en aparecer después de que
  termine el partido — el bot lo va a cargar en la **siguiente corrida** una
  vez que la fuente lo publique, no necesariamente a los 2h10m exactos.
- El sistema reintenta cada 30 minutos indefinidamente hasta encontrar el
  resultado, así que eventualmente siempre se completa.

Si en algún momento conseguimos acceso a una API más rápida (tipo
api-football.com con key gratuita), se puede reemplazar fácilmente la función
`fetch_json` en `scripts/update_results.py` sin tocar el resto.

## 📦 Instalación (subir esto al repo)

Descomprimí este ZIP y subí **todo el contenido** (manteniendo la estructura
de carpetas) a la raíz de tu repo `ProdeDelMundial`:

```
.github/workflows/actualizar-resultados.yml
assets/banner.jpg
assets/ball.png
data/calendario.json
scripts/update_results.py
index.html   (reemplaza el actual)
```

GitHub no deja arrastrar carpetas `.github` fácil desde la web — la forma más
simple es:

1. Entrá a tu repo → **Add file → Upload files**
2. Arrastrá **todo** el contenido descomprimido del ZIP (las carpetas incluidas)
   al cuadro de upload — la mayoría de navegadores permiten arrastrar carpetas
   completas y GitHub las reconstruye con sus rutas.
3. Commit changes.

Si tu navegador no soporta arrastrar carpetas completas, lo más fácil es usar
**GitHub Desktop** (app gratuita) o pedirme ayuda y lo subimos por partes
(carpeta por carpeta) usando "Add file → Create new file" con el path completo
en el nombre, igual que hicimos con `assets/`.

## ✅ Verificar que funciona

1. Después de subir todo, andá a la pestaña **Actions** del repo.
2. Deberías ver el workflow "Actualizar resultados Prode Mundial 2026" listado.
3. Podés disparar una corrida manual con **"Run workflow"** para probarlo.
4. Si encuentra resultados nuevos, vas a ver un commit automático del usuario
   `prode-bot` en el historial.

## 🔑 Permisos necesarios

Por defecto, los Actions tienen permiso de lectura solamente. Para que el bot
pueda hacer commit, verificá en:

**Settings → Actions → General → Workflow permissions** → elegí
**"Read and write permissions"** → Save.
